﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QRCodeGenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if(textBox1.Text == "Unesite string za barcode!")
            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.FromArgb(221, 79, 66);
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if(textBox1.Text == "")
            {
                textBox1.Text = "Unesite string za barcode!";
                textBox1.ForeColor = Color.FromArgb(193, 193, 193);
            }
        }

       
    }
}
